
Github link:
git@github.com:lomaslove/my-portfolio.git

# WELCOME TO THE Portfolio Website!

## Purpose:

To Create A Personal Poetfolio Website! This will be updated in future when i get more skills and experience.

## Functionality/feature

This website pretty much well functions. It has various section where the viewer can get information about me. It includes my work experience, skills, knowledge, my works and much more.

i have linked the navbar list so that its convienent to navigate from one page to another. I have used adequate amount of css to make it look better. I have tried my codes to be dry.

## Instructions for use:
 with the website you can scroll down to view more information or just click on navbar to check in any of the links.

 this website is for anyone who would like to know more about me.
 i will update it whenever needed.

 it is mostly based on html and css. i have used few bootstrap cdn and couple of javscript to look better.

-------------------------------------------------------------------------------------------------------------------

## Design and Planning:
 I went through few portfolio website to get some idea about what to include and how to include and then i designed my own pertfolio and added style to it.

### Brainstorming ideas:
        -single page with toggle bar
        - website which is much clear to read   <-- I picked this one.
        -multiple pages and long


### This particular idea: 
        - includes everything needed
        - more detail information
        - responsive

-------------------------------------------------------------------------------------------------------------------
 
-------------------------------------------------------------------------------------------------------------------
## Future Updates/To be added:
 
 - use bootstrap and javascript to make it better.
 - use scss more to make it professional
 - Add some cool fonts and icons 
 - Allow users to log in and leave comments.
 - a complete working website
----------------------------------------------------------------------------------------------------------------
## Potential Concerns/Issues

This is a personal portfolio website so there aren't many ethical or moral concerns, however it is important to consider its completely personal website.

----------------------------------------------------------------------------------------------------------------
## Project plan:

    Tuesday evening: Brainstorming idea

    Wednesday morning: Create trello and organise MVP code ideas and functionality (including making this README & github repo)

    Tursday : Create outline/MVP & overall website

    Friday: bug fixing and making code look nice & documentation

    Saturday afternoon: extending code (added icons styled) & testing

    Thursday: Presentation & making sure everything works




1.      Describe key events in the development of the internet           from the 1980s to today (max. 150 words)
        The development of internet has gone through many stages. From 1980 there was a significant achievement.
        In the early 80's a computer scientist name Vinton Cerf developed a network and named "transmission Contorl
        Protocol" or TCP and later he added additional protocol known as internet
        Protocol. However, in 1991 internet changed with the invention of World Wide web 
        invented by Tim Berners-Lee. In 1992 a group of students and researchers at the university
        of Illonois developed a sophisticated browser that the called Mosaic which offered a user-friendly
        way to search page for the first time and to navigate using scrollbars and clickable links.
        As a result, companies of all kinds hurried to set up websites of their own.



2.      Define and describes the relationship between                    fundamental aspects of the internet such as: domains,            web servers, DNS, and web browsers (max. 150 words)

        DNS server are used to host and match website adresses to IP adresses. DNS is the main system over
        the internet that uses the name server. when we type URL, the ISP looks up the domain name, finds thematching IP adress and sends it back.

        Domain names are used to identify one or more IP adresses. for example, the domain name Microsoft.com represents about a dozen IP adresses.
        Domain name are used in URL's to identify particular web pages.

        Web Server is a program that uses HTTP(hypertext transfer protocol) to serve the files that from
        web pages to users, in response to their requests, which are forwarded by their computers HTTP clients.

        a web browser, or simply browser is an application used to access and view websites. common web browsers
        include Microsoft Internet Explorer, google chrome, morzilla firefox, and apple safari. the primary function of a web
        browser is to render Html.


3.      Reflect on one aspect of the development of internet             technologies and how it has contributed to the world             today (max. 150 words)
        Technology is very powerful and nothing is as technology at improving life. It can affect life both positively and negatively. new technology always changes our life
        very much and takes it to a new level. It is like the new way of thinking or doing the normal things differently, better and much more faster with less hassle and 
        at a much affordable rate. Eveything has pros and cons. the bright side of technology is without internet life would be very difficult and behind. internet can connect 
        billions of computers and devices to each other. 
        the internet provides useful data, information, and knowledge for the personal, social and 
        economic development and it is up to us to utlizise our time on the worldwide web in a productive manner.
        However, there are few cons as well. some of them are addiction, time wasters and cause distractions. spams and advertising and crime.


# screenshots:

![trello board](https://github.com/lomaslove/
 ![source code] my-portfolio/screnshot/Screenshot (8).png
      
![github] (https://github.com/lomaslove/
![source code] my-portfolio/screnshot/Screenshot (12).png

!'[spreadsheet] (https://github.com/lomaslove/ 
        my-portfolio/screnshot/Screenshot (10).png
       
 
        
         
      